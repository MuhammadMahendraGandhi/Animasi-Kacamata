// Usage: node scripts/srt-to-timing.mjs narasi.srt  -> menulis public/timing.json
import fs from 'node:fs';

const file = process.argv[2];
if (!file) throw new Error('Beri path file .srt');
const raw = fs.readFileSync(file, 'utf8').replace(/\r/g, '');
const toSec = (t) => {
  const m = t.match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};
const cues = raw
  .split(/\n\n+/)
  .map((b) => b.trim().split('\n'))
  .map((l) => {
    const i = l.findIndex((x) => x.includes('-->'));
    if (i < 0) return null;
    const [a, b] = l[i].split('-->').map((s) => s.trim());
    return {start: toSec(a), end: toSec(b), text: l.slice(i + 1).join(' ').trim()};
  })
  .filter((c) => c && c.text && !/UniScribe/i.test(c.text) && c.end > c.start);

const out = JSON.parse(fs.readFileSync('public/timing.json', 'utf8'));
out.scenes = cues.map((c, i) => ({id: i + 1, ...c, scene: out.scenes?.[i]?.scene ?? 'auto'}));
fs.writeFileSync('public/timing.json', JSON.stringify(out, null, 2));
console.log(`${cues.length} adegan ditulis ke public/timing.json`);

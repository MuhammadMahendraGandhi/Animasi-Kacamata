# Si Kaca dan Kakek — animasi Remotion 9:16

Kartun 2D vektor datar (SVG), 1080x1920, 30 fps. Narasi, musik, dan SFX sudah masuk komposisi,
jadi satu perintah render menghasilkan MP4 bersuara.

## Pakai
```bash
npm install
npm run start     # Remotion Studio (pratinjau/penyetelan)
npm run render    # hasil: out/si-kaca.mp4
npm run tsc       # cek tipe
```

## Yang bisa disetel (semua di `public/timing.json`)
- `audioDurationSec`: durasi narasi. Durasi video = ini + `tailSec` (1 detik). **Ganti angka ini bila mengganti narasi.mp3**
  (cek dengan `ffprobe narasi.mp3`). Sekarang 66.951837 detik, jadi video 2039 frame.
- `scenes[]`: satu entri = satu kalimat SRT = satu adegan (`start`, `end`, `text`). `subtitle` adalah teks tampil
  yang sudah dirapikan dari typo transkrip; hapus field itu bila ingin pakai teks SRT apa adanya.
  Untuk mengisi ulang dari SRT baru: `node scripts/srt-to-timing.mjs narasi.srt`.
- `sfx[]`: `scene` (id adegan), `offset` (detik dari awal adegan), `file` (nama di `public/sfx`), `volume`.
- `sky[]`: keyframe langit (warna, bintang, matahari, awan, hujan) per detik.

Koreografi (kamera, gerak Kakek, Kaca, properti) ada di `src/lib/story.ts`, dengan waktu relatif terhadap adegan
(`T('cari', 1.5)` = 1,5 detik setelah adegan "cari" mulai), jadi ikut bergeser bila timing.json diubah.

## Audio
- `public/narasi.mp3`: dipakai apa adanya.
- `public/musik.wav` dan `public/sfx/*.wav`: disintesis oleh `scripts/synth.mjs` (`node scripts/synth.mjs` untuk membuat ulang).
  Volume musik dan hujan diatur di `src/components/AudioMix.tsx`.

## Catatan
- `naskah.txt` dan `screenshot/gaya-*.png` tidak ikut terlampir saat project dibuat; alur cerita diambil dari SRT,
  gaya dari deskripsi (outline hitam tebal, warna flat, satu tingkat bayangan). Palet ada di `src/lib/palette.ts`.
- Project belum pernah dirender di lingkungan pembuatannya, jadi cek hasil visual lewat `npm run start` dulu.

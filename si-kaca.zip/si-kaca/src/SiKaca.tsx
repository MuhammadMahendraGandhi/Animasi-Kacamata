import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {AudioMix} from './components/AudioMix';
import {HouseBack, HouseFront} from './components/House';
import {Apple, Cup} from './components/House';
import {Kaca} from './components/Kaca';
import {Kakek} from './components/Kakek';
import {Sky} from './components/Sky';
import {Subtitles} from './components/Subtitles';
import {World} from './components/World';
import {C} from './lib/palette';
import {
  appleEaten, appleState, camera, focusFlash, kacaState, kakekPose, skyAt, T, WORLD,
  worldBlur, worldSat,
} from './lib/story';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH, prog} from './lib/timing';

export const SiKaca: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;

  const cam = camera(t);
  const sway = Math.sin(t * 0.8) * 3;
  const tx = WIDTH / 2 - cam.cx * cam.s + sway;
  const ty = HEIGHT / 2 - cam.cy * cam.s;

  const pose = kakekPose(t);
  const kaca = kacaState(t);
  const ap = appleState(t);
  const sky = skyAt(t);

  // tempat tidur: selimut di depan Kakek selama masih di kasur
  const tOut = T('buram', 3.0);
  const bedFront = t < tOut ? 1 : Math.max(0, 1 - (t - tOut) / 0.25);

  const holdingCup = t > T('kadang', 3.2);
  const holding =
    ap !== 'meja' && !holdingCup ? (
      <Apple id="apHand" eaten={appleEaten(t)} bite={ap === 'gigit'} />
    ) : holdingCup ? (
      <Cup t={t} />
    ) : undefined;

  const flash = focusFlash(t);
  const goldA = prog(t, T('kadang'), T('dekat', 1.5)) * 0.14;
  const nightA = sky.stars * 0.42 + sky.rain * 0.14;
  const fadeOut = Math.min(1, Math.max(0, (DURATION_FRAMES / FPS - t) / 0.7));
  const fadeInA = Math.min(1, t / 0.4);

  return (
    <AbsoluteFill style={{backgroundColor: C.skyTop}}>
      <AbsoluteFill
        style={{filter: `blur(${worldBlur(t).toFixed(2)}px) saturate(${worldSat(t).toFixed(3)})`}}
      >
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
          <g transform={`translate(${tx} ${ty}) scale(${cam.s})`}>
            <Sky t={t} />
            <World t={t} />
            <HouseBack t={t} front={bedFront} />
            {ap === 'meja' && (
              <g transform={`translate(${WORLD.appleX} ${WORLD.surfaceY - 196})`}>
                <Apple id="apTable" />
              </g>
            )}
            <Kakek pose={pose} holding={holding} walkPhase={pose.x * 0.09}>
              <Kaca state={kaca} t={t} />
            </Kakek>
            <HouseFront front={bedFront} />
            <rect
              x={WORLD.left} y={WORLD.top} width={WORLD.right - WORLD.left} height={WORLD.bottom - WORLD.top}
              fill="#0a1030" opacity={nightA} pointerEvents="none"
            />
            <rect
              x={WORLD.left} y={WORLD.top} width={WORLD.right - WORLD.left} height={WORLD.bottom - WORLD.top}
              fill="#ff9a3c" opacity={goldA} pointerEvents="none"
            />
          </g>
        </svg>
      </AbsoluteFill>
      {/* kilatan fokus saat Kaca mendarat di hidung */}
      <AbsoluteFill style={{background: '#fffbe8', opacity: flash * 0.6, pointerEvents: 'none'}} />
      <Subtitles t={t} />
      <AbsoluteFill style={{background: '#0d0a08', opacity: 1 - Math.min(fadeOut, fadeInA), pointerEvents: 'none'}} />
      <AudioMix />
    </AbsoluteFill>
  );
};

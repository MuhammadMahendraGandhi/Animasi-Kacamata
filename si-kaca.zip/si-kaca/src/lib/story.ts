import {ease, lerp, sceneByKey, timing} from './timing';
import type {Expression, SkyKey} from './types';
import {mix} from './color';

/** Mulai / akhir adegan (detik) dari timing.json, + offset opsional. */
export const T = (key: string, off = 0): number => (sceneByKey(key)?.start ?? 0) + off;
export const E = (key: string, off = 0): number => (sceneByKey(key)?.end ?? 0) + off;

// ---------------------------------------------------------------- dunia
export const WORLD = {
  surfaceY: 1300,
  left: -500,
  right: 2700,
  bottom: 3600,
  top: -900,
  houseL: 40,
  houseR: 1620,
  roomH: 640,
  bedX: 330,
  pillowX: 250,
  nightstandX: 590,
  shoeX: 700,
  fridgeX: 960,
  tableX: 1260,
  appleX: 1250,
  porchX: 1830,
  treeX: 2250,
};

// ---------------------------------------------------------------- kamera
export type Cam = {cx: number; cy: number; s: number};
type CamKey = {t: number} & Cam;

const camKeys = (): CamKey[] => [
  {t: 0, cx: 340, cy: 1130, s: 1.35},
  {t: T('buram'), cx: 470, cy: 1130, s: 1.45},
  {t: T('tanya'), cx: 480, cy: 1130, s: 1.3},
  {t: T('tanya', 3.2), cx: 320, cy: 1120, s: 1.5},
  {t: T('cari', 0.9), cx: 560, cy: 1130, s: 1.4},
  {t: T('cari', 2.7), cx: 880, cy: 1130, s: 1.35},
  {t: T('apel'), cx: 1130, cy: 1130, s: 1.35},
  {t: T('tahukah'), cx: 1150, cy: 1100, s: 1.2},
  {t: T('kepala'), cx: 1150, cy: 930, s: 2.6},
  {t: E('jatuh', -1.2), cx: 1150, cy: 940, s: 3.0},
  {t: E('jatuh', 0.3), cx: 1250, cy: 1100, s: 1.3},
  {t: T('tawa'), cx: 1250, cy: 1100, s: 1.3},
  {t: T('kadang'), cx: 1700, cy: 1100, s: 1.25},
  {t: T('dekat'), cx: 1700, cy: 1100, s: 1.25},
  {t: E('dekat', 0.2), cx: 1100, cy: 1550, s: 0.5},
  {t: 999, cx: 1100, cy: 1550, s: 0.5},
];

export const camera = (t: number): Cam => {
  const k = camKeys();
  for (let i = 0; i < k.length - 1; i++) {
    if (t >= k[i].t && t < k[i + 1].t) {
      const x = ease((t - k[i].t) / Math.max(0.001, k[i + 1].t - k[i].t));
      return {
        cx: lerp(k[i].cx, k[i + 1].cx, x),
        cy: lerp(k[i].cy, k[i + 1].cy, x),
        s: lerp(k[i].s, k[i + 1].s, x),
      };
    }
  }
  return k[0];
};

// ---------------------------------------------------------------- Kakek
export type KPose = {
  x: number; // posisi kaki (dunia)
  rot: number; // derajat, rotasi badan di pinggul (negatif = condong ke kiri)
  crouch: number; // 0..1 membungkuk
  armL: number; // derajat dari posisi tergantung
  armR: number;
  tilt: number; // kemiringan kepala
  mouth: number; // 0..1 mulut terbuka
  expr: Expression;
  face: 1 | -1; // 1 = menghadap kanan
  sit: number; // 0..1 duduk
};

const base: KPose = {
  x: WORLD.bedX, rot: 0, crouch: 0, armL: 8, armR: -8, tilt: 0, mouth: 0,
  expr: 'senang', face: 1, sit: 0,
};

type KKey = {t: number} & Partial<KPose>;

const kakekKeys = (): KKey[] => [
  // adegan 1: bangun, menguap, meraba meja
  {t: 0, x: 330, rot: -90, expr: 'senang', armL: 0, armR: 0},
  {t: 0.9, rot: -90, mouth: 1, armL: 60, armR: 60},
  {t: 1.8, rot: -90, mouth: 0, armL: 10, armR: 10},
  {t: 2.8, x: 440, rot: -30, sit: 1, armR: -70, armL: 20, expr: 'senang'},
  {t: 4.2, x: 440, rot: -22, sit: 1, armR: -95, armL: 20, expr: 'sedih'},
  // adegan 2: buram, meraba nightstand
  {t: T('buram'), x: 440, rot: -20, sit: 1, armR: -100, expr: 'sedih'},
  {t: T('buram', 1.2), armR: -80},
  {t: T('buram', 2.2), armR: -105},
  {t: T('buram', 3.2), x: 470, rot: 0, sit: 0, armR: -10, armL: 10, expr: 'sedih'},
  // adegan 3: kaget lalu menuju bantal
  {t: T('tanya', 0.1), x: 470, rot: 0, expr: 'kaget', mouth: 1, armL: 50, armR: -50},
  {t: T('tanya', 1.4), expr: 'kaget', mouth: 0.2, armL: 20, armR: -20, tilt: -6},
  {t: T('tanya', 2.8), x: 470, expr: 'tekad', tilt: 6, mouth: 0},
  {t: T('tanya', 4.6), x: 330, crouch: 0.2, expr: 'tekad', armR: -20},
  // adegan 4: bantal, sepatu, kulkas
  {t: T('cari', 0.1), x: 330, crouch: 0.6, armR: -40, armL: 30, expr: 'tekad'},
  {t: T('cari', 0.9), x: 340, crouch: 0.7, armR: -55, expr: 'tekad'},
  {t: T('cari', 1.1), x: 600, crouch: 0.1, expr: 'tekad', armR: -10, armL: 10},
  {t: T('cari', 1.5), x: 700, crouch: 0.85, armR: -60, armL: 40, expr: 'tekad', face: 1},
  {t: T('cari', 2.5), x: 720, crouch: 0.85, expr: 'sedih'},
  {t: T('cari', 2.9), x: 900, crouch: 0.1, expr: 'sedih', armR: -20, armL: 20},
  {t: T('cari', 3.3), x: 900, crouch: 0.35, armR: -50, armL: 50, expr: 'sedih', tilt: 8},
  // adegan 5: apel
  {t: T('apel'), x: 1010, crouch: 0.1, expr: 'sedih', armR: -15, armL: 15, tilt: 0},
  {t: T('apel', 0.8), x: 1160, crouch: 0, expr: 'sedih'},
  {t: T('apel', 1.2), x: 1160, expr: 'kaget', armR: -70, mouth: 0.3},
  {t: T('apel', 1.7), x: 1160, armR: -75, armL: 20, expr: 'senang'},
  {t: T('apel', 2.1), x: 1160, armR: -165, armL: 5, expr: 'senang', tilt: -4},
  {t: T('apel', 2.9), armR: -158, expr: 'senang', mouth: 0.8},
  {t: T('apel', 3.3), armR: -158, expr: 'kaget', mouth: 0.5},
  // adegan 6: tahukah (Kakek mengunyah, tak sadar)
  {t: T('tahukah'), x: 1160, armR: 20, armL: 10, expr: 'senang', mouth: 0, tilt: 0},
  {t: T('tahukah', 0.9), mouth: 0.6, expr: 'senang'},
  {t: T('tahukah', 1.4), mouth: 0.1, expr: 'senang'},
  // adegan 7-8: Kakek diam, melirik, tak sadar
  {t: T('kepala', 0.5), x: 1160, armR: 15, armL: 12, expr: 'senang', mouth: 0.3, tilt: 3},
  {t: T('kepala', 2.4), mouth: 0.1, tilt: -3, expr: 'sedih'},
  {t: T('melambai'), expr: 'sedih', tilt: -3, armL: 40, armR: -40, mouth: 0},
  {t: T('melambai', 1.5), expr: 'sedih', tilt: 4, armL: 55, armR: -35},
  // adegan 9-12: Kakek diam, menggaruk dagu, Kaca merayap turun
  {t: T('tekad'), expr: 'sedih', tilt: 2, armL: 12, armR: -12},
  {t: T('meluncur'), expr: 'sedih', tilt: 0, armR: -10},
  {t: T('meluncur', 2.4), tilt: -4, expr: 'kaget', armR: -10, armL: 10},
  {t: T('alis', 0.2), expr: 'kaget', mouth: 0.1, tilt: -6},
  {t: T('jatuh', 1.9), tilt: 0, expr: 'kaget', mouth: 0},
  {t: T('jatuh', 2.6), tilt: 0, expr: 'kaget', mouth: 0.8, armL: 60, armR: -60},
  // adegan 13-14: dunia jelas, tertawa
  {t: T('jelas', 0.4), expr: 'senang', mouth: 0.4, armL: 30, armR: -30, tilt: 4},
  {t: T('jelas', 2.2), expr: 'senang', x: 1160, armL: 10, armR: -10, mouth: 0},
  {t: T('tawa'), expr: 'senang', x: 1160, mouth: 0.9, tilt: -5},
  {t: T('tawa', 0.6), mouth: 0.4, tilt: 5, armL: 30, armR: -30},
  {t: T('tawa', 1.4), mouth: 0.9, tilt: -5},
  {t: T('tawa', 2.2), mouth: 0.4, tilt: 4},
  {t: T('tawa', 3.4), mouth: 0.1, tilt: 0, expr: 'senang', armL: 10, armR: -10},
  // adegan 15-16: berjalan ke teras, duduk minum teh
  {t: T('kadang', 0.2), x: 1160, expr: 'senang', crouch: 0, sit: 0},
  {t: T('kadang', 2.6), x: 1760, expr: 'senang'},
  {t: T('kadang', 3.4), x: 1790, sit: 1, rot: 0, armR: -75, armL: 20, expr: 'senang'},
  {t: T('dekat', 1.6), x: 1790, sit: 1, armR: -75, expr: 'senang', tilt: 3},
  {t: 999, x: 1790, sit: 1, armR: -75, expr: 'senang'},
];

const numKeys: (keyof KPose)[] = ['x', 'rot', 'crouch', 'armL', 'armR', 'tilt', 'mouth', 'sit'];

/** Isi key yang kosong dengan nilai key sebelumnya (carry forward). */
const filled = (): ({t: number} & KPose)[] => {
  const out: ({t: number} & KPose)[] = [];
  let cur: KPose = {...base};
  for (const k of kakekKeys()) {
    cur = {...cur, ...k};
    out.push({...cur, t: k.t});
  }
  return out;
};

export const kakekPose = (t: number): KPose => {
  const k = filled();
  for (let i = 0; i < k.length - 1; i++) {
    if (t >= k[i].t && t < k[i + 1].t) {
      const x = ease((t - k[i].t) / Math.max(0.001, k[i + 1].t - k[i].t));
      const p = {...k[i]} as KPose;
      const rec = p as unknown as Record<string, number>;
      for (const f of numKeys) rec[f] = lerp(k[i][f] as number, k[i + 1][f] as number, x);
      // menghadap arah gerak
      const dx = (k[i + 1].x as number) - (k[i].x as number);
      p.face = Math.abs(dx) > 5 ? (dx > 0 ? 1 : -1) : k[i].face;
      return p;
    }
  }
  const last = k[k.length - 1];
  return {...last} as KPose;
};

// ---------------------------------------------------------------- Kaca
export type KacaState = {
  mode: 'head' | 'forehead' | 'brow' | 'nose';
  // offset lokal terhadap kepala Kakek (kepala di (0,-380))
  x: number;
  y: number;
  rot: number;
  expr: Expression;
  wave: number; // 0..1 gerak kaki-kacamata melambai
  squash: number; // 1 = normal
  wink: number; // 0..1
};

export const kacaState = (t: number): KacaState => {
  const top = -462;
  const fore = -440;
  const brow = -418;
  const nose = -396;
  const wob = (f: number, a: number) => Math.sin(t * f) * a;

  let y = top;
  let x = 0;
  let rot = 0;
  let expr: Expression = 'senang';
  let wave = 0;
  let squash = 1;
  let mode: KacaState['mode'] = 'head';
  let wink = 0;

  const tMelambai = T('melambai');
  const tTekad = T('tekad');
  const tLuncur = T('meluncur');
  const tAlis = T('alis');
  const tJatuh = T('jatuh');
  const tTung = tJatuh + 2.55;

  if (t < tMelambai) {
    // bertengger di atas rambut, "tidur"/mengintip
    expr = 'senang';
    rot = wob(2, 1.2);
    if (t > T('kepala', 0.6)) expr = 'kaget';
    if (t > T('kepala', 2.0)) wave = 0.25 + 0.2 * Math.sin(t * 9);
  } else if (t < tTekad) {
    expr = 'kaget';
    wave = 1;
    rot = wob(14, 6);
    y = top - Math.abs(Math.sin(t * 7)) * 10;
  } else if (t < tLuncur) {
    expr = t < tTekad + 2.0 ? 'sedih' : 'tekad';
    wave = t < tTekad + 2.0 ? 0 : 0.3;
    rot = t < tTekad + 2.0 ? -3 : wob(8, 3);
    squash = t < tTekad + 1.0 ? 1 + 0.04 * Math.sin((t - tTekad) * 5) : 1;
  } else if (t < tAlis) {
    // menggoyang badan, meluncur ke dahi lalu ke alis
    expr = 'tekad';
    const p = (t - tLuncur) / (tAlis - tLuncur + 0.6);
    const s = ease(Math.min(1, Math.max(0, (p - 0.35) / 0.65)));
    y = lerp(top, brow - 1, s);
    rot = wob(18, 8) * (1 - s * 0.6);
    mode = s > 0.6 ? 'brow' : 'forehead';
  } else if (t < tTung) {
    // tersangkut di alis, bergoyang lalu menggeliat
    expr = 'tekad';
    mode = 'brow';
    y = brow;
    rot = wob(22, 4) * (t < tJatuh + 1.7 ? 1 : 0.4);
    if (t > tJatuh + 1.7) y = brow - 3 * Math.sin((t - tJatuh - 1.7) * 14);
  } else {
    // "tung!" jatuh tepat di hidung, memantul kecil
    const d = t - tTung;
    const fall = ease(Math.min(1, d / 0.14));
    const bounce = d > 0.14 ? Math.exp(-(d - 0.14) * 7) * Math.sin((d - 0.14) * 30) * 4 : 0;
    y = lerp(brow, nose, fall) - bounce;
    rot = lerp(wob(10, 3), 0, fall);
    squash = d > 0.1 && d < 0.4 ? 1 - 0.14 * Math.exp(-(d - 0.1) * 10) : 1;
    mode = 'nose';
    expr = d < 0.3 ? 'kaget' : 'senang';
    wink = t > T('jelas', 1.4) && t < T('jelas', 2.2) ? 1 : 0;
    if (t > E('tawa', -1.2) && t < E('tawa', -0.3)) wink = 1;
    if (t > T('dekat', 0.3) && t < T('dekat', 1.0)) wink = 1;
  }
  return {mode, x, y, rot, expr, wave, squash, wink};
};

// ---------------------------------------------------------------- properti
/** 0..1 seberapa terangkat bantal. */
export const pillowLift = (t: number): number => {
  const a = T('cari', 0.1);
  const b = T('cari', 1.0);
  if (t < a || t > b + 0.2) return 0;
  return t < a + 0.3 ? ease((t - a) / 0.3) : t > b ? 1 - ease((t - b) / 0.2) : 1;
};

/** Pintu kulkas terbuka 0..1. */
export const fridgeOpen = (t: number): number => {
  const a = T('cari', 3.1);
  return ease(Math.min(1, Math.max(0, (t - a) / 0.35)));
};

/** Sepatu terangkat (dicari) 0..1. */
export const shoeLift = (t: number): number => {
  const a = T('cari', 1.5);
  const b = T('cari', 2.7);
  return t < a || t > b ? 0 : Math.sin(((t - a) / (b - a)) * Math.PI);
};

export type AppleState = 'meja' | 'tangan' | 'gigit';
export const appleState = (t: number): AppleState => {
  if (t < T('apel', 1.9)) return 'meja';
  if (t < T('apel', 2.9)) return 'tangan';
  return 'gigit';
};

/** Apel dimakan habis perlahan setelah digigit (kunyah) 0..1. */
export const appleEaten = (t: number): number =>
  t < T('apel', 2.9) ? 0 : Math.min(1, (t - T('apel', 2.9)) / 4);

/** Kilatan fokus ketika Kaca mendarat. */
export const focusFlash = (t: number): number => {
  const a = T('jatuh') + 2.55;
  const d = t - a;
  return d < 0 || d > 0.9 ? 0 : Math.exp(-d * 5) * Math.min(1, d / 0.04);
};

/** Blur dunia (sudut pandang Kakek tanpa kacamata). */
export const worldBlur = (t: number): number => {
  const tTanya = T('tanya', 0.2);
  if (t < tTanya) return 7;
  if (t < tTanya + 1.2) return lerp(7, 2, ease((t - tTanya) / 1.2));
  if (t < T('jatuh') + 2.55) return 2;
  const d = (t - T('jatuh') - 2.55) / 0.5;
  return lerp(2, 0, ease(Math.min(1, Math.max(0, d))));
};

/** Kejenuhan warna dunia: pucat sebelum jelas, penuh warna sesudahnya. */
export const worldSat = (t: number): number => {
  const a = T('jatuh') + 2.55;
  if (t < T('tanya', 0.2)) return 0.7;
  if (t < a) return 0.8;
  const d = Math.min(1, (t - a) / 0.6);
  return lerp(0.8, 1.2, ease(d));
};

// ---------------------------------------------------------------- langit
export type SkyNow = {top: string; bottom: string; stars: number; sun: number; cloud: number; rain: number};

export const skyAt = (t: number): SkyNow => {
  const k: SkyKey[] = timing.sky;
  let i = 0;
  while (i < k.length - 1 && t >= k[i + 1].t) i++;
  const a = k[i];
  const b = k[Math.min(i + 1, k.length - 1)];
  const x = b.t === a.t ? 0 : ease(Math.min(1, Math.max(0, (t - a.t) / (b.t - a.t))));
  return {
    top: mix(a.top, b.top, x),
    bottom: mix(a.bottom, b.bottom, x),
    stars: lerp(a.stars, b.stars, x),
    sun: lerp(a.sun, b.sun, x),
    cloud: lerp(a.cloud, b.cloud, x),
    rain: lerp(a.rain, b.rain, x),
  };
};

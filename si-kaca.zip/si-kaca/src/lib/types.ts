export type SceneKey =
  | 'bangun' | 'buram' | 'tanya' | 'cari' | 'apel' | 'tahukah' | 'kepala' | 'melambai'
  | 'tekad' | 'meluncur' | 'alis' | 'jatuh' | 'jelas' | 'tawa' | 'kadang' | 'dekat' | 'auto';

export type SceneTiming = {
  id: number;
  start: number; // detik, dari SRT
  end: number;
  text: string; // teks asli SRT
  subtitle?: string; // teks subtitle yang sudah dirapikan (opsional)
  scene: SceneKey;
};

export type Timing = {
  fps: number;
  audioDurationSec: number;
  tailSec: number;
  scenes: SceneTiming[];
  sfx: SfxCue[];
  sky: SkyKey[];
};

export type Expression = 'senang' | 'sedih' | 'kaget' | 'tekad';

export type SfxCue = {scene: number; offset: number; file: string; volume: number};

export type SkyKey = {
  t: number;
  top: string;
  bottom: string;
  stars: number; // 0..1
  sun: number; // 0..1 (tinggi matahari)
  cloud: number; // 0..1
  rain: number; // 0..1 intensitas hujan
};

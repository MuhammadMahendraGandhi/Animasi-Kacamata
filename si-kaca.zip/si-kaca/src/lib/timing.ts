import timingJson from '../../public/timing.json';
import type {SceneTiming, Timing} from './types';

export const timing = timingJson as unknown as Timing;
export const FPS = timing.fps;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_FRAMES = Math.ceil((timing.audioDurationSec + timing.tailSec) * FPS);

export const sec = (s: number): number => Math.round(s * FPS);

export const sceneByKey = (k: string): SceneTiming | undefined =>
  timing.scenes.find((s) => s.scene === k);

/** Adegan aktif pada detik tertentu (adegan terakhir yang sudah mulai). */
export const sceneAt = (t: number): SceneTiming | undefined => {
  let cur: SceneTiming | undefined;
  for (const s of timing.scenes) if (t >= s.start) cur = s;
  return cur;
};

/** Progres 0..1 di dalam rentang detik [a,b], dijepit. */
export const prog = (t: number, a: number, b: number): number =>
  b <= a ? (t >= b ? 1 : 0) : Math.min(1, Math.max(0, (t - a) / (b - a)));

export const ease = (x: number): number => x * x * (3 - 2 * x);
export const lerp = (a: number, b: number, x: number): number => a + (b - a) * x;

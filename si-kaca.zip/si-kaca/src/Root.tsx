import React from 'react';
import {Composition} from 'remotion';
import {SiKaca} from './SiKaca';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './lib/timing';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="SiKaca"
    component={SiKaca}
    durationInFrames={DURATION_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);

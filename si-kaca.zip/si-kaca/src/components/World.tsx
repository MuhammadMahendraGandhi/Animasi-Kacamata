import React from 'react';
import {C, OUT_S, OUT_W} from '../lib/palette';
import {WORLD} from '../lib/story';
import {prog} from '../lib/timing';

const L = WORLD.left;
const R = WORLD.right;
const SY = WORLD.surfaceY;
const BOT = WORLD.bottom;

const hash = (n: number): number => {
  const x = Math.sin(n * 91.7 + 17.3) * 43758.5453;
  return x - Math.floor(x);
};

type Stone = {x: number; y: number; rx: number; ry: number; rot: number};
const stones: Stone[] = [
  {x: 200, y: 1520, rx: 90, ry: 58, rot: -8},
  {x: 900, y: 1650, rx: 120, ry: 76, rot: 6},
  {x: 1450, y: 1500, rx: 70, ry: 46, rot: -12},
  {x: 600, y: 2000, rx: 140, ry: 88, rot: 10},
  {x: 1300, y: 2200, rx: 160, ry: 98, rot: -5},
  {x: 400, y: 2650, rx: 120, ry: 78, rot: 14},
  {x: 1700, y: 2500, rx: 150, ry: 94, rot: -9},
  {x: 900, y: 2950, rx: 170, ry: 100, rot: 4},
  {x: 2250, y: 2700, rx: 130, ry: 84, rot: 12},
  {x: 90, y: 1950, rx: 70, ry: 48, rot: -6},
  {x: 1120, y: 1440, rx: 56, ry: 38, rot: 8},
  {x: 2000, y: 3150, rx: 150, ry: 90, rot: -10},
];

const StoneShape: React.FC<{s: Stone}> = ({s}) => {
  const {rx, ry} = s;
  const d = `M${-rx} ${ry * 0.2} Q${-rx * 0.9} ${-ry * 0.9} ${-rx * 0.1} ${-ry} Q${rx * 0.8} ${-ry * 0.95} ${rx} ${-ry * 0.1} Q${rx * 0.95} ${ry * 0.9} ${rx * 0.1} ${ry} Q${-rx * 0.8} ${ry * 0.95} ${-rx} ${ry * 0.2}Z`;
  return (
    <g transform={`translate(${s.x} ${s.y}) rotate(${s.rot})`}>
      <path d={d} fill={C.rock} stroke={C.outline} strokeWidth={OUT_W} strokeLinejoin="round" />
      <path d={`M${rx * 0.15} ${-ry * 0.95} Q${rx * 0.95} ${-ry * 0.85} ${rx} ${-ry * 0.1} Q${rx * 0.95} ${ry * 0.9} ${rx * 0.1} ${ry} Q${rx * 0.6} ${ry * 0.2} ${rx * 0.15} ${-ry * 0.95}Z`} fill={C.rockDark} />
      <path d={`M${-rx * 0.6} ${-ry * 0.35} Q${-rx * 0.35} ${-ry * 0.7} ${-rx * 0.05} ${-ry * 0.72}`} stroke={C.rockLight} strokeWidth={OUT_S + 1} fill="none" strokeLinecap="round" />
      <path d={`M${-rx * 0.1} ${-ry * 0.1} L${rx * 0.12} ${ry * 0.3}`} stroke={C.outline} strokeWidth={OUT_S - 1} strokeLinecap="round" />
    </g>
  );
};

const roots: {d: string; a: number; b: number; w: number}[] = [
  {d: 'M2250 1300 C2240 1450 2150 1560 2020 1650 C1900 1730 1800 1800 1650 1830', a: 8, b: 30, w: 16},
  {d: 'M2250 1300 C2200 1420 2060 1480 1900 1470 C1760 1460 1650 1500 1520 1560', a: 14, b: 40, w: 13},
  {d: 'M2250 1300 C2260 1480 2300 1640 2250 1820 C2220 1930 2160 2020 2100 2120', a: 20, b: 48, w: 15},
  {d: 'M2250 1300 C2330 1420 2440 1500 2540 1640', a: 26, b: 50, w: 12},
  {d: 'M2020 1650 C1990 1760 1930 1860 1840 1960', a: 34, b: 58, w: 10},
  {d: 'M2250 1820 C2160 1900 2080 2000 1950 2060', a: 44, b: 64, w: 9},
  {d: 'M1900 1470 C1880 1560 1820 1620 1760 1700', a: 30, b: 52, w: 8},
];

const cracks: {d: string; a: number; b: number}[] = [
  {d: 'M760 1360 L735 1420 L770 1470 L742 1540 L778 1600', a: 15, b: 32},
  {d: 'M460 1380 L486 1440 L452 1500 L480 1560', a: 22, b: 40},
  {d: 'M1360 1330 L1338 1396 L1372 1450 L1346 1510', a: 36, b: 56},
];

export const World: React.FC<{t: number}> = ({t}) => {
  return (
    <g>
      <defs>
        <linearGradient id="soilG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={C.soilTop} />
          <stop offset="0.45" stopColor={C.soilMid} />
          <stop offset="1" stopColor={C.soilBottom} />
        </linearGradient>
      </defs>
      {/* tanah */}
      <rect x={L} y={SY} width={R - L} height={BOT - SY} fill="url(#soilG)" />
      {/* bintik tanah */}
      {Array.from({length: 150}, (_, i) => (
        <ellipse
          key={i}
          cx={L + hash(i) * (R - L)}
          cy={SY + 60 + hash(i + 40) * (BOT - SY - 80)}
          rx={5 + hash(i + 9) * 9}
          ry={3 + hash(i + 5) * 5}
          fill="#000"
          opacity={0.1 + hash(i + 2) * 0.08}
        />
      ))}
      {/* batu */}
      {stones.map((s, i) => <StoneShape key={i} s={s} />)}
      {/* retakan */}
      {cracks.map((c, i) => (
        <path key={i} d={c.d} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - prog(t, c.a, c.b)}
          stroke={C.crack} strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      ))}
      {/* akar tergambar bertahap */}
      {roots.map((r, i) => {
        const p = prog(t, r.a, r.b);
        return (
          <g key={i}>
            <path d={r.d} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p}
              stroke={C.outline} strokeWidth={r.w + 7} fill="none" strokeLinecap="round" />
            <path d={r.d} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p}
              stroke={C.root} strokeWidth={r.w} fill="none" strokeLinecap="round" />
          </g>
        );
      })}
      {/* permukaan: rumput */}
      <rect x={L} y={SY - 8} width={R - L} height={34} fill={C.grass} />
      <rect x={L} y={SY + 14} width={R - L} height={14} fill={C.grassDark} />
      <line x1={L} y1={SY + 28} x2={R} y2={SY + 28} stroke={C.outline} strokeWidth={OUT_W} />
      <line x1={L} y1={SY - 8} x2={R} y2={SY - 8} stroke={C.outline} strokeWidth={OUT_W} />
      {Array.from({length: 70}, (_, i) => {
        const x = L + hash(i + 300) * (R - L);
        const sway = Math.sin(t * 2 + i) * 3;
        return (
          <path key={i} d={`M${x - 8} ${SY - 8} Q${x - 4 + sway} ${SY - 30} ${x + sway} ${SY - 38} Q${x + 4 + sway} ${SY - 24} ${x + 8} ${SY - 8}`}
            fill={C.grass} stroke={C.outline} strokeWidth={OUT_S - 1} strokeLinejoin="round" />
        );
      })}
      {/* pohon di kanan */}
      <g transform={`translate(${WORLD.treeX} ${SY - 8})`}>
        <path d="M-40 0 Q-30 -250 -22 -430 L22 -430 Q30 -250 40 0Z" fill={C.wood} stroke={C.outline} strokeWidth={OUT_W} strokeLinejoin="round" />
        <path d="M6 -420 L22 -430 Q30 -250 40 0 L10 0Z" fill={C.woodDark} />
        <g transform={`rotate(${Math.sin(t * 1.3) * 0.8} 0 -430)`}>
          {[[-110, -520, 120], [100, -530, 125], [0, -620, 140], [-30, -480, 120]].map(([x, y, r], i) => (
            <circle key={i} cx={x} cy={y} r={r} fill={i % 2 ? C.grass : C.grassDark} stroke={C.outline} strokeWidth={OUT_W} />
          ))}
          <circle cx={-10} cy={-640} r={70} fill={C.grass} />
        </g>
      </g>
    </g>
  );
};

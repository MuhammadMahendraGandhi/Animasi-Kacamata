import React from 'react';
import {C, OUT_S} from '../lib/palette';
import type {KacaState} from '../lib/story';

const lw = {stroke: C.outline, strokeWidth: 4.5, strokeLinecap: 'round' as const, fill: 'none'};

const Eyes: React.FC<{expr: KacaState['expr']; wink: number}> = ({expr, wink}) => {
  const eye = (cx: number, left: boolean) => {
    if (wink > 0.5 && left) return <path d={`M${cx - 9} 0 L${cx + 9} 0`} {...lw} />;
    switch (expr) {
      case 'senang':
        return <path d={`M${cx - 9} 4 Q${cx} -9 ${cx + 9} 4`} {...lw} />;
      case 'sedih':
        return <path d={left ? `M${cx - 9} -3 L${cx + 9} 4` : `M${cx - 9} 4 L${cx + 9} -3`} {...lw} />;
      case 'kaget':
        return <circle cx={cx} cy={0} r={5.5} fill={C.outline} />;
      default:
        return <path d={`M${cx - 9} 0 L${cx + 9} 0`} {...lw} />;
    }
  };
  return (
    <>
      {eye(-32, true)}
      {eye(32, false)}
    </>
  );
};

/** Kacamata bulat berkarakter. Origin = pusat jembatan hidung. worn = dipakai (lensa bening). */
export const Kaca: React.FC<{state: KacaState; t: number}> = ({state, t}) => {
  const worn = state.mode === 'nose';
  const sw = state.wave * Math.sin(t * 20) * 38;
  const lens = worn ? 'rgba(207,238,255,0.38)' : C.lens;
  const brow =
    state.expr === 'tekad'
      ? ['M-48 -30 L-18 -22', 'M18 -22 L48 -30']
      : state.expr === 'kaget'
      ? ['M-48 -32 Q-32 -42 -16 -32', 'M16 -32 Q32 -42 48 -32']
      : state.expr === 'sedih'
      ? ['M-46 -24 L-18 -32', 'M18 -32 L46 -24']
      : null;
  return (
    <g transform={`translate(${state.x} ${state.y + 380}) rotate(${state.rot}) scale(${1} ${state.squash})`}>
      {/* gagang (tangan melambai) */}
      <g transform={`translate(-57 -4) rotate(${-sw})`}>
        <path d="M0 0 L-34 6" stroke={C.outline} strokeWidth={8} strokeLinecap="round" />
        <path d="M0 0 L-34 6" stroke={C.glass} strokeWidth={3.5} strokeLinecap="round" />
      </g>
      <g transform={`translate(57 -4) rotate(${sw})`}>
        <path d="M0 0 L34 6" stroke={C.outline} strokeWidth={8} strokeLinecap="round" />
        <path d="M0 0 L34 6" stroke={C.glass} strokeWidth={3.5} strokeLinecap="round" />
      </g>
      {/* jembatan */}
      <path d="M-10 -6 Q0 -16 10 -6" stroke={C.outline} strokeWidth={8} fill="none" strokeLinecap="round" />
      <path d="M-10 -6 Q0 -16 10 -6" stroke={C.glass} strokeWidth={3.5} fill="none" strokeLinecap="round" />
      {/* lensa */}
      {[-32, 32].map((cx) => (
        <g key={cx}>
          <circle cx={cx} cy={0} r={26} fill={lens} stroke={C.outline} strokeWidth={8} />
          <circle cx={cx} cy={0} r={26} fill="none" stroke={C.glass} strokeWidth={3.5} />
          <path d={`M${cx - 14} -12 Q${cx - 8} -19 ${cx} -19`} stroke="#fff" strokeWidth={4} fill="none" strokeLinecap="round" opacity={0.9} />
        </g>
      ))}
      {!worn && <Eyes expr={state.expr} wink={state.wink} />}
      {!worn && brow && brow.map((d, i) => <path key={i} d={d} {...lw} />)}
      {/* mulut kecil di bawah jembatan (hanya saat tidak dipakai) */}
      {!worn && (
        <path
          d={state.expr === 'sedih' ? 'M-9 38 Q0 30 9 38' : state.expr === 'kaget' ? 'M-4 34 Q0 44 4 34' : 'M-10 32 Q0 44 10 32'}
          {...lw}
        />
      )}
      {/* dipakai: pipi bangga + kedipan */}
      {worn && (
        <>
          <circle cx={-52} cy={20} r={6} fill="#ff8f8f" opacity={0.55} />
          <circle cx={52} cy={20} r={6} fill="#ff8f8f" opacity={0.55} />
          {state.wink > 0.5 && (
            <g transform="translate(-32 -2)" stroke={C.outline} strokeWidth={OUT_S} strokeLinecap="round">
              <path d="M-9 0 L9 0" strokeWidth={6} />
            </g>
          )}
          {state.wink > 0.5 && <path d="M-72 -34 l4 -10 l4 10 l10 4 l-10 4 l-4 10 l-4 -10 l-10 -4z" fill="#ffe98a" stroke={C.outline} strokeWidth={2.5} strokeLinejoin="round" />}
        </>
      )}
    </g>
  );
};

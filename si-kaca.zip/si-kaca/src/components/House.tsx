import React from 'react';
import {C, OUT_S, OUT_W} from '../lib/palette';
import {fridgeOpen, pillowLift, shoeLift, skyAt, WORLD} from '../lib/story';

const SY = WORLD.surfaceY;
const HL = WORLD.houseL;
const HR = WORLD.houseR;
const RH = WORLD.roomH;
const TOP = SY - RH;

const o = {stroke: C.outline, strokeWidth: OUT_W, strokeLinejoin: 'round' as const};
const os = {stroke: C.outline, strokeWidth: OUT_S, strokeLinejoin: 'round' as const};

export const Apple: React.FC<{id: string; eaten?: number; bite?: boolean}> = ({id, eaten = 0, bite = false}) => {
  const sc = 1 - eaten * 0.55;
  return (
    <g transform={`scale(${sc})`}>
      <defs>
        <mask id={id}>
          <rect x={-40} y={-40} width={80} height={80} fill="#fff" />
          {bite && <circle cx={17} cy={-6} r={11} fill="#000" />}
        </mask>
      </defs>
      <g mask={`url(#${id})`}>
        <circle cx={0} cy={2} r={23} fill={C.apple} />
        <path d="M6 -18 Q26 -4 14 18 Q4 24 -2 23 Q22 8 6 -18Z" fill={C.appleDark} opacity={0.7} />
      </g>
      <circle cx={0} cy={2} r={23} fill="none" {...os} mask={bite ? `url(#${id})` : undefined} />
      <path d="M0 -20 Q2 -30 8 -34" stroke={C.outline} strokeWidth={4} fill="none" strokeLinecap="round" />
      <path d="M4 -28 Q16 -38 24 -28 Q14 -22 4 -28Z" fill={C.grass} {...os} />
      <path d="M-14 -4 Q-12 -12 -6 -14" stroke="#fff" strokeWidth={4} fill="none" strokeLinecap="round" opacity={0.8} />
    </g>
  );
};

export const Cup: React.FC<{t: number}> = ({t}) => (
  <g>
    <path d="M-17 -14 L17 -14 L13 20 Q0 26 -13 20Z" fill="#fff8ea" {...os} />
    <path d="M15 -6 Q34 -6 28 10 Q24 16 14 14" fill="none" stroke={C.outline} strokeWidth={5} strokeLinecap="round" />
    <path d="M-15 -4 L15 -4" stroke="#d86f5a" strokeWidth={5} />
    {[-6, 6].map((x, i) => (
      <path key={i} d={`M${x} -22 q${5 + Math.sin(t * 4 + i) * 3} -9 0 -18 q${-5} -9 0 -16`} stroke="#fff"
        strokeWidth={4} fill="none" strokeLinecap="round" opacity={0.85} />
    ))}
  </g>
);

const Shoe: React.FC<{x: number; lift?: number; flip?: boolean}> = ({x, lift = 0, flip}) => (
  <g transform={`translate(${x} ${SY - 12 - lift * 70}) rotate(${-lift * 20}) scale(${flip ? -1 : 1} 1)`}>
    <path d="M-34 0 L-34 -24 Q-8 -34 12 -22 L40 -12 Q48 -6 40 0Z" fill="#6b4b38" {...os} />
    <path d="M-36 0 L42 0" stroke={C.outline} strokeWidth={8} strokeLinecap="round" />
    <path d="M-14 -26 L-10 -12" stroke="#e6d6bd" strokeWidth={4} strokeLinecap="round" />
  </g>
);

/** Lapisan belakang: dinding, jendela, perabot. Kakek digambar sesudahnya. */
export const HouseBack: React.FC<{t: number; front: number}> = ({t, front}) => {
  const sky = skyAt(t);
  const pl = pillowLift(t);
  const fo = fridgeOpen(t);
  const sl = shoeLift(t);
  const dw = Math.cos(fo * 1.35);
  return (
    <g>
      {/* dinding belakang */}
      <rect x={HL} y={TOP} width={HR - HL} height={RH} fill={C.wall} {...o} />
      <rect x={HL} y={SY - 70} width={HR - HL} height={70} fill={C.wallShade} />
      <line x1={HL} y1={SY - 70} x2={HR} y2={SY - 70} stroke={C.outline} strokeWidth={OUT_S} />
      {/* lantai kayu */}
      <rect x={HL - 20} y={SY - 14} width={HR - HL + 40} height={26} fill={C.wood} {...o} />
      {Array.from({length: 26}, (_, i) => (
        <line key={i} x1={HL + 30 + i * 62} y1={SY - 14} x2={HL + 30 + i * 62} y2={SY + 12} stroke={C.outline} strokeWidth={3} />
      ))}
      {/* jendela (warna langit ikut berubah) */}
      <g transform={`translate(430 ${TOP + 110})`}>
        <rect x={-100} y={0} width={200} height={190} fill={sky.bottom} {...o} />
        <rect x={-100} y={0} width={200} height={190} fill={sky.top} opacity={0.55} />
        <line x1={0} y1={0} x2={0} y2={190} stroke={C.outline} strokeWidth={OUT_S + 1} />
        <line x1={-100} y1={95} x2={100} y2={95} stroke={C.outline} strokeWidth={OUT_S + 1} />
        <path d="M-84 20 L-40 20 L-84 64Z" fill="#fff" opacity={0.35} />
      </g>
      {/* gambar bingkai di dapur */}
      <g transform={`translate(1130 ${TOP + 150})`}>
        <rect x={-60} y={-44} width={120} height={88} fill="#e9d29a" {...o} />
        <path d="M-44 28 L-14 -12 L8 14 L22 -2 L44 28Z" fill={C.grass} {...os} />
        <circle cx={26} cy={-20} r={11} fill="#ffd54f" {...os} />
      </g>
      {/* sekat kamar/dapur */}
      <rect x={780} y={TOP} width={26} height={RH - 250} fill={C.wallShade} {...o} />
      {/* ===== kamar tidur ===== */}
      <g>
        {/* tempat tidur */}
        <rect x={110} y={SY - 70} width={460} height={58} fill={C.wood} {...o} />
        <rect x={110} y={SY - 250} width={26} height={238} fill={C.woodDark} {...o} />
        <rect x={136} y={SY - 118} width={434} height={50} rx={12} fill="#fff8ea" {...o} />
        <rect x={550} y={SY - 14} width={20} height={14} fill={C.woodDark} {...os} />
        <Blanket opacity={1 - front} />
        {/* bantal */}
        <g transform={`translate(${WORLD.pillowX} ${SY - 142 - pl * 80}) rotate(${pl * -22})`}>
          <ellipse cx={0} cy={0} rx={82} ry={30} fill="#fffdf5" {...o} />
          <path d="M-60 6 Q0 24 60 6" stroke={C.shirtShade} strokeWidth={5} fill="none" strokeLinecap="round" />
        </g>
        {/* meja samping + lampu */}
        <rect x={WORLD.nightstandX - 48} y={SY - 130} width={96} height={118} fill={C.wood} {...o} />
        <rect x={WORLD.nightstandX - 34} y={SY - 112} width={68} height={34} fill={C.woodDark} {...os} />
        <circle cx={WORLD.nightstandX} cy={SY - 95} r={5} fill={C.outline} />
        <path d={`M${WORLD.nightstandX - 24} ${SY - 130} L${WORLD.nightstandX - 14} ${SY - 190} L${WORLD.nightstandX + 14} ${SY - 190} L${WORLD.nightstandX + 24} ${SY - 130}Z`} fill="#f5c04e" {...os} />
        {/* sepatu */}
        <Shoe x={WORLD.shoeX - 46} />
        <Shoe x={WORLD.shoeX + 46} lift={sl} flip />
      </g>
      {/* ===== dapur ===== */}
      <g>
        {/* kulkas */}
        <g transform={`translate(${WORLD.fridgeX - 75} ${SY - 340})`}>
          <rect x={0} y={0} width={150} height={340} fill={C.fridgeShade} {...o} />
          <rect x={8} y={8} width={134} height={324} fill={fo > 0.02 ? '#fff4c4' : C.fridge} stroke="none" />
          {fo > 0.02 && (
            <g>
              {[70, 140, 210, 270].map((y) => (
                <line key={y} x1={10} y1={y} x2={140} y2={y} stroke={C.outline} strokeWidth={4} />
              ))}
              <circle cx={44} cy={52} r={16} fill={C.apple} {...os} />
              <rect x={86} y={30} width={34} height={40} fill="#6bb3e0" {...os} />
              <rect x={30} y={106} width={80} height={32} fill="#f4d98a" {...os} />
            </g>
          )}
          <g transform={`scale(${dw} 1)`}>
            <rect x={0} y={0} width={150} height={340} fill={C.fridge} {...o} />
            <rect x={0} y={118} width={150} height={0} stroke={C.outline} strokeWidth={OUT_S} />
            <line x1={0} y1={118} x2={150} y2={118} stroke={C.outline} strokeWidth={OUT_S} />
            <rect x={116} y={36} width={10} height={60} rx={5} fill={C.outline} />
            <rect x={116} y={150} width={10} height={80} rx={5} fill={C.outline} />
            <path d="M14 14 L14 100" stroke="#fff" strokeWidth={6} strokeLinecap="round" opacity={0.7} />
          </g>
        </g>
        {/* meja makan */}
        <rect x={WORLD.tableX - 130} y={SY - 170} width={260} height={22} fill={C.wood} {...o} />
        <rect x={WORLD.tableX - 110} y={SY - 148} width={20} height={136} fill={C.woodDark} {...o} />
        <rect x={WORLD.tableX + 90} y={SY - 148} width={20} height={136} fill={C.woodDark} {...o} />
        {/* teko */}
        <g transform={`translate(${WORLD.tableX + 70} ${SY - 196})`}>
          <path d="M-22 0 Q-26 -34 0 -38 Q26 -34 22 0Z" fill="#6bb3e0" {...os} />
          <path d="M22 -14 Q44 -24 40 -40" fill="none" stroke={C.outline} strokeWidth={6} strokeLinecap="round" />
        </g>
      </g>
      {/* ===== atap & teras ===== */}
      <g>
        <path d={`M${HL - 70} ${TOP + 4} L${(HL + HR) / 2 + 60} ${TOP - 190} L${HR + 330} ${TOP + 4}Z`}
          fill={C.roof} {...o} />
        <path d={`M${(HL + HR) / 2 + 60} ${TOP - 190} L${HR + 330} ${TOP + 4} L${(HL + HR) / 2 + 60} ${TOP + 4}Z`} fill={C.roofDark} opacity={0.65} />
        {Array.from({length: 7}, (_, i) => (
          <line key={i} x1={HL - 40 + i * 128} y1={TOP - 4} x2={(HL + HR) / 2 + 60} y2={TOP - 186}
            stroke={C.outline} strokeWidth={3} opacity={0.35} />
        ))}
        {/* lantai & tiang teras */}
        <rect x={HR} y={SY - 14} width={400} height={26} fill={C.wood} {...o} />
        <rect x={HR + 360} y={TOP + 4} width={26} height={RH - 10} fill={C.woodDark} {...o} />
        {/* kursi teras */}
        <g transform={`translate(${WORLD.porchX} ${SY - 14})`}>
          <rect x={-62} y={-70} width={124} height={16} fill={C.wood} {...o} />
          <rect x={-56} y={-54} width={14} height={54} fill={C.woodDark} {...os} />
          <rect x={42} y={-54} width={14} height={54} fill={C.woodDark} {...os} />
          <rect x={-70} y={-190} width={16} height={122} fill={C.woodDark} {...o} />
        </g>
        {/* meja teh */}
        <rect x={WORLD.porchX + 150} y={SY - 130} width={110} height={16} fill={C.wood} {...o} />
        <rect x={WORLD.porchX + 196} y={SY - 114} width={18} height={100} fill={C.woodDark} {...os} />
      </g>
    </g>
  );
};

const Blanket: React.FC<{opacity: number}> = ({opacity}) => (
  <g opacity={opacity}>
    <path d={`M300 ${SY - 112} Q430 ${SY - 140} 566 ${SY - 112} L566 ${SY - 62} L300 ${SY - 62}Z`}
      fill={C.blanket} {...o} />
    <path d={`M420 ${SY - 124} Q470 ${SY - 130} 566 ${SY - 112} L566 ${SY - 62} L420 ${SY - 62}Z`} fill={C.blanketShade} opacity={0.6} />
  </g>
);

/** Lapisan depan (menutupi Kakek yang berbaring / duduk di tempat tidur): selimut. */
export const HouseFront: React.FC<{front: number}> = ({front}) => <Blanket opacity={front} />;

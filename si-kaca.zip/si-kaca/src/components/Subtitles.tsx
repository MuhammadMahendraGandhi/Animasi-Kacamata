import React from 'react';
import {sceneAt, timing} from '../lib/timing';

export const Subtitles: React.FC<{t: number}> = ({t}) => {
  const sc = sceneAt(t);
  if (!sc) return null;
  const next = timing.scenes.find((s) => s.start > sc.start);
  const holdUntil = next ? Math.min(sc.end + 0.35, next.start) : sc.end + 0.8;
  if (t > holdUntil) return null;
  const text = sc.subtitle ?? sc.text;
  const words = text.split(/\s+/).filter(Boolean);
  const dur = Math.max(0.1, sc.end - sc.start);
  const cur = Math.min(words.length - 1, Math.floor(((t - sc.start) / dur) * words.length));
  const fadeIn = Math.min(1, Math.max(0, (t - sc.start) / 0.15 + 0.2));
  const fadeOut = Math.min(1, Math.max(0, (holdUntil - t) / 0.15));
  return (
    <div
      style={{
        position: 'absolute',
        left: 60,
        right: 60,
        bottom: 190,
        display: 'flex',
        justifyContent: 'center',
        opacity: Math.min(fadeIn, fadeOut),
        transform: `translateY(${(1 - Math.min(fadeIn, 1)) * 16}px)`,
      }}
    >
      <div
        style={{
          background: 'rgba(26,20,16,0.82)',
          border: '5px solid #1a1410',
          borderRadius: 34,
          padding: '24px 34px',
          textAlign: 'center',
          fontFamily: '"Trebuchet MS", "Verdana", "DejaVu Sans", sans-serif',
          fontWeight: 800,
          fontSize: 58,
          lineHeight: 1.22,
          color: '#fffdf5',
          letterSpacing: 0.5,
          boxShadow: '0 8px 0 rgba(0,0,0,0.25)',
        }}
      >
        {words.map((w, i) => (
          <span key={i} style={{color: i <= cur ? '#ffe27a' : '#fffdf5'}}>
            {w}
            {i < words.length - 1 ? ' ' : ''}
          </span>
        ))}
      </div>
    </div>
  );
};

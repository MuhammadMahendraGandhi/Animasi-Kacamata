import React from 'react';
import {C, OUT_S, OUT_W} from '../lib/palette';
import {ease, lerp} from '../lib/timing';
import type {Expression} from '../lib/types';
import type {KPose} from '../lib/story';

const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

/** Panjang lengan: memendek saat tangan diangkat ke wajah. */
const armLen = (a: number): number => lerp(150, 90, ease(clamp01((Math.abs(a) - 105) / 55)));

/** Posisi tangan kanan (lokal kaki-origin, sebelum rotasi badan). */
export const handR = (a: number): {x: number; y: number} => {
  const L = armLen(a);
  const r = (a * Math.PI) / 180;
  return {x: 58 + -Math.sin(r) * L, y: -290 + Math.cos(r) * L};
};

const Arm: React.FC<{sx: number; angle: number; sleeve?: boolean}> = ({sx, angle, sleeve = true}) => {
  const L = armLen(angle);
  const bend = angle < 0 ? -16 : 16;
  const d = `M0 0 Q${bend} ${L * 0.5} 0 ${L}`;
  return (
    <g transform={`translate(${sx} -290) rotate(${angle})`}>
      <path d={d} stroke={C.outline} strokeWidth={34} strokeLinecap="round" fill="none" />
      <path d={d} stroke={C.skin} strokeWidth={22} strokeLinecap="round" fill="none" />
      {sleeve && (
        <>
          <path d={`M0 0 L0 52`} stroke={C.outline} strokeWidth={46} strokeLinecap="round" />
          <path d={`M0 0 L0 52`} stroke={C.shirt} strokeWidth={36} strokeLinecap="round" />
        </>
      )}
      <circle cx={0} cy={L} r={15} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
    </g>
  );
};

const Face: React.FC<{expr: Expression; mouth: number}> = ({expr, mouth}) => {
  const lw = {stroke: C.outline, strokeWidth: 6, strokeLinecap: 'round' as const, fill: 'none'};
  const my = 14; // mulut di bawah kumis
  const m = mouth;
  const eyes = (() => {
    switch (expr) {
      case 'senang':
        return (
          <>
            <path d="M-38 -6 Q-26 -20 -14 -6" {...lw} />
            <path d="M14 -6 Q26 -20 38 -6" {...lw} />
          </>
        );
      case 'sedih':
        return (
          <>
            <path d="M-38 -2 L-14 -9" {...lw} />
            <path d="M14 -9 L38 -2" {...lw} />
          </>
        );
      case 'kaget':
        return (
          <>
            <path d="M-26 -17 L-26 0" {...lw} strokeWidth={8} />
            <path d="M26 -17 L26 0" {...lw} strokeWidth={8} />
          </>
        );
      default:
        return (
          <>
            <path d="M-38 -6 L-14 -6" {...lw} />
            <path d="M14 -6 L38 -6" {...lw} />
          </>
        );
    }
  })();
  const brows = (() => {
    const b = {stroke: C.hair, strokeWidth: 11, strokeLinecap: 'round' as const, fill: 'none'};
    const bo = {stroke: C.outline, strokeWidth: 17, strokeLinecap: 'round' as const, fill: 'none'};
    const paths =
      expr === 'sedih'
        ? ['M-42 -22 L-14 -32', 'M14 -32 L42 -22']
        : expr === 'kaget'
        ? ['M-40 -36 Q-26 -46 -12 -36', 'M12 -36 Q26 -46 40 -36']
        : expr === 'tekad'
        ? ['M-42 -34 L-12 -22', 'M12 -22 L42 -34']
        : ['M-40 -28 Q-26 -36 -12 -28', 'M12 -28 Q26 -36 40 -28'];
    return (
      <>
        {paths.map((p, i) => <path key={`o${i}`} d={p} {...bo} />)}
        {paths.map((p, i) => <path key={`b${i}`} d={p} {...b} />)}
      </>
    );
  })();
  const mouthShape =
    m > 0.15 ? (
      <ellipse cx={0} cy={my + 6} rx={12 + m * 6} ry={4 + m * 14} fill={C.outline} />
    ) : expr === 'sedih' ? (
      <path d={`M-14 ${my + 6} Q0 ${my - 4} 14 ${my + 6}`} {...lw} />
    ) : expr === 'senang' ? (
      <path d={`M-16 ${my} Q0 ${my + 12} 16 ${my}`} {...lw} />
    ) : (
      <path d={`M-12 ${my + 3} L12 ${my + 3}`} {...lw} />
    );
  return (
    <g transform="translate(0 -8)">
      {brows}
      {eyes}
      {mouthShape}
    </g>
  );
};

/** Kepala digambar di (0,0) = pusat kepala. children = Kaca (koordinat kepala). */
const Head: React.FC<{expr: Expression; mouth: number; tilt: number; children?: React.ReactNode}> = ({
  expr, mouth, tilt, children,
}) => (
  <g transform={`translate(0 -380) rotate(${tilt})`}>
    {/* telinga */}
    <circle cx={-70} cy={4} r={15} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
    <circle cx={70} cy={4} r={15} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
    {/* kepala */}
    <ellipse cx={0} cy={0} rx={70} ry={74} fill={C.skin} stroke={C.outline} strokeWidth={OUT_W} />
    <path d="M30 -62 Q72 -30 62 30 Q40 70 0 74 Q54 40 30 -62Z" fill={C.skinShade} opacity={0.55} />
    {/* rambut putih: tipis di sisi + sedikit di atas */}
    <path d="M-70 -6 Q-84 -50 -52 -64 Q-20 -86 14 -72 Q-44 -62 -56 -22 Q-60 -4 -70 -6Z"
      fill={C.hair} stroke={C.outline} strokeWidth={OUT_S + 1} strokeLinejoin="round" />
    <path d="M70 -6 Q84 -50 52 -64 Q26 -80 8 -74 Q50 -58 58 -20 Q62 -4 70 -6Z"
      fill={C.hair} stroke={C.outline} strokeWidth={OUT_S + 1} strokeLinejoin="round" />
    {/* hidung */}
    <ellipse cx={0} cy={6} rx={11} ry={9} fill={C.skinShade} stroke={C.outline} strokeWidth={OUT_S} />
    <g transform="translate(0 -2)"><Face expr={expr} mouth={mouth} /></g>
    {/* kumis putih tebal */}
    <path
      d="M0 16 Q-14 6 -34 12 Q-58 20 -56 36 Q-40 28 -22 28 Q-8 28 0 22 Q8 28 22 28 Q40 28 56 36 Q58 20 34 12 Q14 6 0 16Z"
      fill={C.hair} stroke={C.outline} strokeWidth={OUT_S + 1} strokeLinejoin="round"
    />
    {children}
  </g>
);

export const Kakek: React.FC<{
  pose: KPose;
  holding?: React.ReactNode;
  children?: React.ReactNode; // Kaca, dalam koordinat kepala
  walkPhase: number;
}> = ({pose, holding, children, walkPhase}) => {
  const lie = clamp01(-pose.rot / 90);
  const drop = lie * 62 + pose.sit * 74 + pose.crouch * 46;
  const lean = pose.crouch * 34;
  const swing = Math.sin(walkPhase) * 14;
  const stepping = pose.sit < 0.5 && lie < 0.3 ? 1 : 0;
  const bob = stepping * Math.abs(Math.sin(walkPhase)) * -3;
  const hp = handR(pose.armR);

  return (
    <g transform={`translate(${pose.x} ${WORLD_Y}) scale(${pose.face} 1)`}>
      {/* bayangan lantai: satu tingkat */}
      <ellipse cx={0} cy={4} rx={86} ry={11} fill="#000" opacity={0.18} />
      <g transform={`translate(0 ${drop + bob}) rotate(${pose.rot + lean} 0 -170)`}>
        {/* kaki */}
        <ellipse cx={-26 + swing} cy={-9} rx={28} ry={13} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
        <ellipse cx={26 - swing} cy={-9} rx={28} ry={13} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} />
        <Arm sx={-58} angle={pose.armL} />
        {/* sarung */}
        <path d="M-64 -178 L64 -178 Q82 -110 76 -26 Q0 -14 -76 -26 Q-82 -110 -64 -178Z"
          fill={C.sarong} stroke={C.outline} strokeWidth={OUT_W} strokeLinejoin="round" />
        <path d="M18 -178 L64 -178 Q82 -110 76 -26 Q40 -20 18 -22Z" fill={C.sarongShade} opacity={0.7} />
        <path d="M-80 -112 Q0 -98 80 -112 L78 -84 Q0 -70 -78 -84Z" fill={C.sarongStripe}
          stroke={C.outline} strokeWidth={OUT_S} strokeLinejoin="round" />
        <path d="M-6 -178 Q8 -120 -2 -40" stroke={C.outline} strokeWidth={OUT_S} fill="none" strokeLinecap="round" />
        {/* kaos oblong */}
        <path d="M-60 -304 Q0 -322 60 -304 L64 -168 Q0 -156 -64 -168Z"
          fill={C.shirt} stroke={C.outline} strokeWidth={OUT_W} strokeLinejoin="round" />
        <path d="M22 -312 L60 -304 L64 -168 Q40 -162 22 -163Z" fill={C.shirtShade} opacity={0.8} />
        <path d="M-24 -314 Q0 -290 24 -314" stroke={C.outline} strokeWidth={OUT_S} fill="none" strokeLinecap="round" />
        {/* leher */}
        <rect x={-18} y={-326} width={36} height={26} fill={C.skin} stroke={C.outline} strokeWidth={OUT_S} rx={8} />
        <path d="M-24 -314 Q0 -290 24 -314 L24 -318 L-24 -318Z" fill={C.skin} />
        <Head expr={pose.expr} mouth={pose.mouth} tilt={pose.tilt}>{children}</Head>
        <Arm sx={58} angle={pose.armR} />
        {holding && <g transform={`translate(${hp.x} ${hp.y})`}>{holding}</g>}
      </g>
    </g>
  );
};

const WORLD_Y = 1300;
